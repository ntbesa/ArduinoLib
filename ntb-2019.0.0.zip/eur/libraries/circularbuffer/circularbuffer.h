/***************************************************************************//**
* @file    circularbuffer.h
* @version 0.1
* @author  Samuel Kranz
* @date    11.04.2017
* @brief   CircularBuffer class
*
* @par     Changelog
*
* <table>
*   <tr><th>Version   <th>Date      <th>User    <th>Description
*   <tr><td>0.1       <td>02170411  <td>KRAS    <td>File created
* </table>
*
* @copyright     Copyright 2018 NTB Buchs,
*                all Rights reserved.
*                http://www.ntb.ch/esa
*
******************************************************************************/

#ifndef CIRCULARBUFFER_h
#define CIRCULARBUFFER_h
#include <inttypes.h>
#include <string.h>

template < typename T, uint16_t Size >
class CircularBuffer 
{

public:
  CircularBuffer() :
    wp_ ( buf_ ), rp_( buf_ ), tail_ ( buf_ + Size ),  remain_( 0 ) {}
  
  ~CircularBuffer() {}
  
  inline void push ( T value ) 
  {
    *wp_++ = value;
    remain_++;
    if ( wp_ == tail_ ) wp_ = buf_;
  }
  
  inline T pop() 
  {
    T result = *rp_++;
    remain_--;
    if ( rp_ == tail_ ) rp_ = buf_;
    return result;
  }
  
  inline uint16_t remain() const { return remain_; }

  void clear(){ memset(buf_, 0, Size); }
  
private:
  T buf_[Size];
  T *wp_;
  T *rp_;
  T *tail_;
  uint16_t remain_;
};

#endif
