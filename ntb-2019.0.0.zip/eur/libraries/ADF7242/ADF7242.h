/***************************************************************************//**
* @file    ADF7242.h
* @version 0.2
* @author  Samuel Kranz
* @date    11.11.2016
* @brief   ADF7242 tranceiver library header
*
* @par     Changelog
*
* <table>
*   <tr><th>Version   <th>Date      <th>User    <th>Description
*   <tr><td>0.1       <td>20161111  <td>KRAS    <td>File ported to c++
*   <tr><td>0.2       <td>20180507  <td>KRAS    <td>Complete rewrite
* </table>
*
* @copyright     Copyright 2018 NTB Buchs,
*                all Rights reserved.
*                http://www.ntb.ch/esa
*
******************************************************************************/

#ifndef ADF7242_H_
#define ADF7242_H_

/*******************************************************************************
* Includes
******************************************************************************/

#include "SPI.h"

/*******************************************************************************
* Public Types
******************************************************************************/

typedef enum
{
  Status_Idle = 1,
  Status_Meas = 2,
  Status_PhyRdy = 3,
  Status_RX = 4,
  Status_TX = 5,
  Status_Sleep = 6,
  Status_CCA = 7
}
ADF7242_Status_TypeDef;

typedef enum 
{
  DataRate_50kbps,
  DataRate_62k5bps,
  DataRate_100kbps,
  DataRate_125kbps,
  DataRate_250kbps,
  DataRate_500kbps,
  DataRate_1000kbps,
  DataRate_2000kbps
}
ADF7242_DataRate_TypeDef;

typedef enum 
{
  Modulation_DSSS_OQPSK_PacketMode,
  Modulation_DSSS_OQPSK_SportMode,
  Modulation_GFSK_FSK_PacketMode,
  Modulation_GFSK_FSK_SportMode
}
ADF7242_Modulation_TypeDef;

typedef enum
{
  IRQ_PowerUp = 1,
  IRQ_WakeUp = 2,
  IRQ_RcReady = 3,
  IRQ_POR = 4,
  IRQ_BatteryAlert = 5,
  IRQ_CCAcomplete = 8,
  IRQ_RxPacketReceived = 11,
  IRQ_TxPacketSent = 12
} 
ADF7242_InterruptSource_TypeDef;

typedef enum
{
  IRQ_Channel0 = 0,
  IRQ_Channel1 = 1
} 
ADF7242_InterruptChannel_TypeDef;

typedef enum
{
  LNA_1 = 0,
  LNA_2 = 1
} 
ADF7242_LNA_TypeDef;

typedef struct 
{
  uint8_t Word2;
  uint8_t Word1;
  uint8_t Word0;
  uint8_t Length;
  uint8_t ErrorTol;
} 
ADF7242_SyncWord_TypeDef;

typedef struct 
{
  uint8_t Polarity;
  uint8_t Mode;
  uint8_t Kp;
  uint8_t Ki;
  uint8_t Range;
} 
ADF7242_AFC_TypeDef;

typedef struct 
{
  uint8_t RampRate;
  uint8_t EnableHighPower;
  uint8_t PowerLevel;
} 
ADF7242_PA_TypeDef;

typedef struct
{
  ADF7242_InterruptChannel_TypeDef Channel;
  ADF7242_InterruptSource_TypeDef Source;
}
ADF7242_Interrupt_TypeDef;

typedef struct 
{
  uint32_t ChannelFrequency;
  
  ADF7242_Modulation_TypeDef Modulation;
  ADF7242_DataRate_TypeDef Datarate;
  ADF7242_SyncWord_TypeDef Syncword;
  ADF7242_AFC_TypeDef AFCconfig;
  ADF7242_PA_TypeDef PAconfig;
  uint8_t RxBaseAddress;
  uint8_t TxBaseAddress;
} 
ADF7242_Config_TypeDef;

/*******************************************************************************
* Public Constants
******************************************************************************/

/*Syncwords*/

//Dolby E Startcode 24bit
#define SYNC_WORD_DOLBY_24 {                    \
  ( 0x07 ),                                     \
  ( 0x88 ),                                     \
  ( 0x8E ),                                     \
  ( 24 ),                                       \
  ( 0 )                                         \
 }

//Analog Devices Example 21bit
#define SYNC_WORD_AD_21 {                       \
  ( 0xBD ),                                     \
  ( 0x39 ),                                     \
  ( 0x44 ),                                     \
  ( 21 ),                                       \
  ( 0 )                                         \
 }
      
//Analog Devices Example 16bit
#define SYNC_WORD_AD_16 {                       \
  ( 0xAA ),                                     \
  ( 0x7F ),                                     \
  ( 0x31 ),                                     \
  ( 16 ),                                       \
  ( 0 )                                         \
 }
 
//Dect sync word 16bit
#define SYNC_WORD_DECT_16 {                     \
  ( 0xAA ),                                     \
  ( 0xE9 ),                                     \
  ( 0x4A ),                                     \
  ( 16 ),                                       \
  ( 0 )                                         \
 }

     
//Bisync sync word 8bit
#define SYNC_WORD_BISYNC_8 {                    \
  ( 0xAA ),                                     \
  ( 0xAA ),                                     \
  ( 0x16 ),                                     \
  ( 8 ),                                        \
  ( 0 )                                         \
 }
 
#define AFC_CONFIG_DEFAULT {                    \
  ( 0x1 ),                                      \
  ( 0x3 ),                                      \
  ( 0x9 ),                                      \
  ( 0x9 ),                                      \
  ( 80 )                                        \
 }

#define PA_CONFIG_DEFAULT {                     \
  ( 7 ),                                        \
  ( 0 ),                                        \
  ( 15 )                                        \
 }
 
#define PA_CONFIG_HIGHPOWER {                   \
  ( 7 ),                                        \
  ( 1 ),                                        \
  ( 15 )                                        \
 }

#define RX_INTERRUPT_CONFIG_DEFAULT {           \
  IRQ_Channel0,                                 \
  IRQ_RxPacketReceived                          \
}

#define TX_INTERRUPT_CONFIG_DEFAULT {           \
  IRQ_Channel0,                                 \
  IRQ_TxPacketSent                              \
}

#define ADF7242_CONFIG_DEFAULT {                \
  ( 2450 ),                                     \
  Modulation_GFSK_FSK_PacketMode,               \
  DataRate_250kbps,                             \
  SYNC_WORD_DECT_16,                            \
  AFC_CONFIG_DEFAULT,                           \
  PA_CONFIG_HIGHPOWER,                          \
  ( 0x00 ),                                     \
  ( 0x80 )                                      \
 }
 
/*******************************************************************************
* Class Definition
******************************************************************************/

class ADF7242
{
  private:
    void spiRelease();
    void spiSelect();
    uint8_t waitReady ( uint8_t mask );
    uint8_t readReg ( uint16_t addr, uint8_t *data );
    uint8_t writeReg ( uint16_t addr, uint8_t data );
    uint8_t writeRegCheck ( uint16_t addr, uint8_t data );
    uint8_t writeRegOr ( uint16_t addr, uint8_t data );
    uint8_t writeRegAnd ( uint16_t addr, uint8_t data );
    uint8_t writeCmd ( uint8_t cmd );
    uint8_t setDataRateFSK( ADF7242_DataRate_TypeDef );

  public:    
    ADF7242 ( uint8_t chipselect );
    uint8_t status();
    uint8_t begin ( ADF7242_Config_TypeDef config );
    uint8_t init( void );
    uint8_t setDataRate ( ADF7242_Config_TypeDef config );
    uint8_t setChannelFrequency ( uint16_t channelFrequency );
    uint8_t setModulation ( ADF7242_Modulation_TypeDef modulation );
    uint8_t setSyncWord ( ADF7242_SyncWord_TypeDef swd );
    uint8_t setAutomaticFrequencyControl ( ADF7242_AFC_TypeDef afc );
    uint8_t setPowerAmplifier ( ADF7242_PA_TypeDef pa );
    uint8_t selectLowNoiseAmplifier ( ADF7242_LNA_TypeDef lna );
    uint8_t setPacketBufferBaseAddresses ( uint8_t rxBase, uint8_t txBase );
    uint8_t switchState ( ADF7242_Status_TypeDef state );
    uint8_t switchStateWait ( ADF7242_Status_TypeDef state );
    uint8_t writeTxBuf ( uint8_t *data, uint8_t len );
    uint8_t readRxBuf ( uint8_t *data, uint8_t len );
    uint8_t addInterrupt ( ADF7242_Interrupt_TypeDef irq );
    uint8_t removeInterrupt ( ADF7242_Interrupt_TypeDef irq );
    uint8_t removeAllInterrupts ( void );
    uint8_t clearInterrupt ( ADF7242_Interrupt_TypeDef irq );
    uint8_t clearAllInterrupts ( void );

    uint8_t dumpRegisters ( uint16_t* regMap, uint8_t* data, uint8_t len ) ;
};

#endif /* ADF7242_H_ */


































